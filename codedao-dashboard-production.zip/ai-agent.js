// CodeDAO AI Agent Integration System
class CodeDAOAIAgent {
    constructor() {
        this.isConnected = false;
        this.sessionId = null;
        this.currentProject = null;
        this.agentCapabilities = [
            'code-review',
            'smart-contract-audit',
            'debugging-assistance',
            'optimization-suggestions',
            'documentation-generation',
            'test-creation',
            'refactoring-help',
            'deployment-guidance'
        ];
        this.init();
    }

    init() {
        this.createAgentInterface();
        this.setupEventListeners();
        this.loadUserPreferences();
    }

    createAgentInterface() {
        // Create AI Agent Panel
        const agentPanel = document.createElement('div');
        agentPanel.id = 'ai-agent-panel';
        agentPanel.className = 'ai-agent-panel';
        agentPanel.innerHTML = `
            <div class="agent-header">
                <div class="agent-status">
                    <div class="status-indicator" id="agent-status"></div>
                    <span id="agent-name">CodeDAO AI Agent</span>
                </div>
                <div class="agent-controls">
                    <button id="connect-agent" class="btn-primary">Connect Agent</button>
                    <button id="agent-settings" class="btn-secondary">⚙️</button>
                </div>
            </div>

            <div class="agent-capabilities">
                <h4>🤖 Available Assistance:</h4>
                <div class="capability-grid">
                    <div class="capability-card" data-type="code-review">
                        <span class="icon">📝</span>
                        <span>Code Review</span>
                    </div>
                    <div class="capability-card" data-type="smart-contract-audit">
                        <span class="icon">🛡️</span>
                        <span>Contract Audit</span>
                    </div>
                    <div class="capability-card" data-type="debugging-assistance">
                        <span class="icon">🐛</span>
                        <span>Debug Help</span>
                    </div>
                    <div class="capability-card" data-type="optimization-suggestions">
                        <span class="icon">⚡</span>
                        <span>Optimization</span>
                    </div>
                    <div class="capability-card" data-type="documentation-generation">
                        <span class="icon">📚</span>
                        <span>Documentation</span>
                    </div>
                    <div class="capability-card" data-type="deployment-guidance">
                        <span class="icon">🚀</span>
                        <span>Deployment</span>
                    </div>
                </div>
            </div>

            <div class="agent-chat" id="agent-chat" style="display: none;">
                <div class="chat-messages" id="chat-messages"></div>
                <div class="chat-input-container">
                    <textarea id="chat-input" placeholder="Ask your AI agent for help..."></textarea>
                    <div class="chat-actions">
                        <button id="send-message" class="btn-primary">Send</button>
                        <button id="share-code" class="btn-secondary">Share Code</button>
                        <button id="request-review" class="btn-secondary">Request Review</button>
                    </div>
                </div>
            </div>

            <div class="agent-suggestions" id="agent-suggestions">
                <h4>💡 Smart Suggestions:</h4>
                <div id="suggestions-container"></div>
            </div>
        `;

        // Add to dashboard
        document.body.appendChild(agentPanel);
    }

    setupEventListeners() {
        // Connect Agent
        document.getElementById('connect-agent').addEventListener('click', () => {
            this.connectAgent();
        });

        // Capability Cards
        document.querySelectorAll('.capability-card').forEach(card => {
            card.addEventListener('click', () => {
                this.requestAssistance(card.dataset.type);
            });
        });

        // Chat functionality
        document.getElementById('send-message').addEventListener('click', () => {
            this.sendMessage();
        });

        document.getElementById('chat-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        // Code sharing
        document.getElementById('share-code').addEventListener('click', () => {
            this.shareCodeWithAgent();
        });

        document.getElementById('request-review').addEventListener('click', () => {
            this.requestCodeReview();
        });
    }

    async connectAgent() {
        const connectBtn = document.getElementById('connect-agent');
        const statusIndicator = document.getElementById('agent-status');
        
        connectBtn.textContent = 'Connecting...';
        connectBtn.disabled = true;

        try {
            // Simulate agent connection (in real implementation, this would connect to AI service)
            await this.simulateConnection();
            
            this.isConnected = true;
            this.sessionId = this.generateSessionId();
            
            statusIndicator.className = 'status-indicator connected';
            connectBtn.textContent = 'Connected ✓';
            
            document.getElementById('agent-chat').style.display = 'block';
            
            this.showWelcomeMessage();
            this.analyzeDashboardContext();
            
            showNotification('🤖 AI Agent connected! Ready to assist with your CodeDAO project.');
            
        } catch (error) {
            statusIndicator.className = 'status-indicator error';
            connectBtn.textContent = 'Connection Failed';
            connectBtn.disabled = false;
            showNotification('Failed to connect AI Agent. Please try again.');
        }
    }

    async simulateConnection() {
        // Simulate network delay
        return new Promise(resolve => setTimeout(resolve, 2000));
    }

    generateSessionId() {
        return 'codedao_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    showWelcomeMessage() {
        this.addChatMessage('agent', `
            🤖 **CodeDAO AI Agent Connected!**
            
            I'm here to help with your CodeDAO project. I can assist with:
            
            • **Smart Contract Development** - Audit, optimize, and debug
            • **Dashboard Enhancement** - UI/UX improvements and Web3 integration
            • **Code Review** - Best practices and security analysis
            • **Documentation** - Generate comprehensive docs
            • **Deployment** - Guide through deployment process
            
            **What would you like to work on first?**
        `);
    }

    analyzeDashboardContext() {
        // Analyze current dashboard state
        const walletConnected = currentAccount !== null;
        const tokenBalance = document.getElementById('tokenBalance').textContent;
        
        let suggestions = [];
        
        if (!walletConnected) {
            suggestions.push({
                type: 'wallet-connection',
                title: 'Connect Wallet',
                description: 'I notice your wallet isn\'t connected. Would you like help with wallet integration?',
                action: 'connect-wallet'
            });
        }
        
        if (tokenBalance === '0 CODE' || tokenBalance === '0.00 CODE') {
            suggestions.push({
                type: 'token-earning',
                title: 'Earn CODE Tokens',
                description: 'Let me help you set up the VS Code extension to start earning CODE tokens for coding!',
                action: 'setup-extension'
            });
        }
        
        // Check for common improvements
        suggestions.push({
            type: 'optimization',
            title: 'Dashboard Optimization',
            description: 'I can analyze your dashboard and suggest performance improvements.',
            action: 'analyze-dashboard'
        });
        
        this.displaySuggestions(suggestions);
    }

    displaySuggestions(suggestions) {
        const container = document.getElementById('suggestions-container');
        container.innerHTML = '';
        
        suggestions.forEach(suggestion => {
            const suggestionCard = document.createElement('div');
            suggestionCard.className = 'suggestion-card';
            suggestionCard.innerHTML = `
                <div class="suggestion-content">
                    <h5>${suggestion.title}</h5>
                    <p>${suggestion.description}</p>
                </div>
                <button class="suggestion-action" data-action="${suggestion.action}">
                    Help Me
                </button>
            `;
            
            suggestionCard.querySelector('.suggestion-action').addEventListener('click', () => {
                this.handleSuggestionAction(suggestion.action, suggestion);
            });
            
            container.appendChild(suggestionCard);
        });
    }

    async requestAssistance(type) {
        if (!this.isConnected) {
            showNotification('Please connect to an AI agent first.');
            return;
        }

        const messages = {
            'code-review': 'I\'d like you to review my code for best practices and potential issues.',
            'smart-contract-audit': 'Please audit my smart contracts for security vulnerabilities.',
            'debugging-assistance': 'I\'m having trouble with some code. Can you help me debug it?',
            'optimization-suggestions': 'Can you suggest optimizations for my code performance?',
            'documentation-generation': 'Help me generate documentation for my project.',
            'deployment-guidance': 'I need guidance on deploying my contracts and dashboard.'
        };

        this.addChatMessage('user', messages[type]);
        
        // Simulate AI response
        setTimeout(() => {
            this.generateAIResponse(type);
        }, 1000);
    }

    generateAIResponse(type) {
        const responses = {
            'code-review': `
🔍 **Code Review Request Received**

I'll analyze your codebase for:
• Code quality and best practices
• Security vulnerabilities
• Performance optimizations
• Documentation completeness

Please share your code files or repository link, and I'll provide a detailed review with actionable recommendations.
            `,
            'smart-contract-audit': `
🛡️ **Smart Contract Audit**

I'll perform a comprehensive audit covering:
• **Security Analysis** - Reentrancy, overflow, access control
• **Gas Optimization** - Reduce transaction costs
• **Best Practices** - OpenZeppelin patterns, upgradability
• **Testing Coverage** - Suggest test cases

Share your contract files and I'll provide a detailed security report.
            `,
            'debugging-assistance': `
🐛 **Debug Assistance Ready**

I can help with:
• **Error Analysis** - Interpret error messages and stack traces
• **Logic Issues** - Review code flow and identify problems
• **Integration Bugs** - Web3, wallet connections, contract interactions
• **Performance Issues** - Identify bottlenecks

Share your error details or problematic code, and let's solve it together!
            `,
            'optimization-suggestions': `
⚡ **Performance Optimization**

I'll analyze for:
• **Gas Efficiency** - Optimize contract operations
• **Frontend Performance** - Reduce load times, improve UX
• **Code Structure** - Better organization and maintainability
• **Database Queries** - If using any backend services

Share your code and current performance metrics for targeted suggestions.
            `,
            'documentation-generation': `
📚 **Documentation Generation**

I can create:
• **README files** - Installation, usage, API documentation
• **Code Comments** - Inline documentation for functions
• **Architecture Diagrams** - System design and flow charts
• **User Guides** - How to use your dashboard and features

What type of documentation would you like me to start with?
            `,
            'deployment-guidance': `
🚀 **Deployment Guidance**

I'll help you deploy:
• **Smart Contracts** - To Base mainnet/testnet with verification
• **Dashboard** - GitHub Pages, Netlify, or custom hosting
• **CI/CD Pipeline** - Automated testing and deployment
• **Monitoring** - Set up alerts and analytics

What are you looking to deploy first?
            `
        };

        this.addChatMessage('agent', responses[type]);
    }

    addChatMessage(sender, message) {
        const messagesContainer = document.getElementById('chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${sender}`;
        
        const timestamp = new Date().toLocaleTimeString();
        messageDiv.innerHTML = `
            <div class="message-content">
                <div class="message-text">${this.parseMarkdown(message)}</div>
                <div class="message-time">${timestamp}</div>
            </div>
        `;
        
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    parseMarkdown(text) {
        return text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/•/g, '•')
            .replace(/\n/g, '<br>');
    }

    sendMessage() {
        const input = document.getElementById('chat-input');
        const message = input.value.trim();
        
        if (!message) return;
        
        this.addChatMessage('user', message);
        input.value = '';
        
        // Simulate AI response
        setTimeout(() => {
            this.generateContextualResponse(message);
        }, 1000);
    }

    generateContextualResponse(userMessage) {
        // Analyze user message and generate appropriate response
        const lowerMessage = userMessage.toLowerCase();
        
        let response = '';
        
        if (lowerMessage.includes('contract') || lowerMessage.includes('solidity')) {
            response = `🔧 **Smart Contract Assistance**

I can help with your Solidity contracts! Based on your message, here are some suggestions:

• **Code Review** - I'll analyze your contract structure and security
• **Gas Optimization** - Reduce transaction costs
• **Testing** - Create comprehensive test suites
• **Documentation** - Generate clear contract documentation

Would you like to share your contract code for specific assistance?`;
        } else if (lowerMessage.includes('dashboard') || lowerMessage.includes('frontend')) {
            response = `🎨 **Dashboard Enhancement**

I can help improve your CodeDAO dashboard:

• **UI/UX Improvements** - Better user experience design
• **Web3 Integration** - Optimize wallet connections and transactions
• **Performance** - Faster loading and responsive design
• **Features** - Add new functionality and components

What specific aspect would you like to work on?`;
        } else if (lowerMessage.includes('error') || lowerMessage.includes('bug')) {
            response = `🐛 **Debug Mode Activated**

Let's solve this together! Please share:

• **Error message** - The exact error you're seeing
• **Code snippet** - The problematic code section
• **Steps to reproduce** - How the error occurs
• **Expected behavior** - What should happen instead

I'll analyze it and provide a solution with explanation.`;
        } else {
            response = `🤖 **AI Assistant**

I understand you need help with: "${userMessage}"

I can assist with:
• Smart contract development and auditing
• Dashboard enhancement and optimization
• Debugging and troubleshooting
• Code review and best practices
• Documentation and deployment

Could you provide more details about what specific help you need?`;
        }
        
        this.addChatMessage('agent', response);
    }

    shareCodeWithAgent() {
        // Create modal for code sharing
        const modal = this.createCodeSharingModal();
        document.body.appendChild(modal);
    }

    createCodeSharingModal() {
        const modal = document.createElement('div');
        modal.className = 'code-sharing-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>📝 Share Code with AI Agent</h3>
                    <button class="close-modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="code-input-section">
                        <label>Code Language:</label>
                        <select id="code-language">
                            <option value="solidity">Solidity</option>
                            <option value="javascript">JavaScript</option>
                            <option value="typescript">TypeScript</option>
                            <option value="html">HTML</option>
                            <option value="css">CSS</option>
                        </select>
                    </div>
                    <div class="code-input-section">
                        <label>Code to Analyze:</label>
                        <textarea id="code-content" placeholder="Paste your code here..."></textarea>
                    </div>
                    <div class="analysis-options">
                        <label>Analysis Type:</label>
                        <div class="option-grid">
                            <label><input type="checkbox" value="security"> Security Review</label>
                            <label><input type="checkbox" value="optimization"> Optimization</label>
                            <label><input type="checkbox" value="best-practices"> Best Practices</label>
                            <label><input type="checkbox" value="documentation"> Documentation</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="analyze-code" class="btn-primary">Analyze Code</button>
                    <button class="close-modal btn-secondary">Cancel</button>
                </div>
            </div>
        `;

        // Add event listeners
        modal.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', () => {
                document.body.removeChild(modal);
            });
        });

        modal.querySelector('#analyze-code').addEventListener('click', () => {
            this.analyzeSharedCode(modal);
        });

        return modal;
    }

    analyzeSharedCode(modal) {
        const language = modal.querySelector('#code-language').value;
        const code = modal.querySelector('#code-content').value;
        const options = Array.from(modal.querySelectorAll('input[type="checkbox"]:checked'))
                           .map(cb => cb.value);

        if (!code.trim()) {
            showNotification('Please paste some code to analyze.');
            return;
        }

        document.body.removeChild(modal);

        this.addChatMessage('user', `Please analyze this ${language} code for: ${options.join(', ')}`);
        
        // Simulate detailed code analysis
        setTimeout(() => {
            this.generateCodeAnalysis(language, code, options);
        }, 2000);
    }

    generateCodeAnalysis(language, code, options) {
        let analysis = `🔍 **Code Analysis Complete**\n\n`;
        analysis += `**Language:** ${language.charAt(0).toUpperCase() + language.slice(1)}\n`;
        analysis += `**Analysis Type:** ${options.join(', ')}\n\n`;

        // Generate different analyses based on options
        if (options.includes('security')) {
            analysis += `🛡️ **Security Analysis:**\n`;
            analysis += `• No obvious security vulnerabilities detected\n`;
            analysis += `• Consider adding input validation\n`;
            analysis += `• Implement proper access controls\n\n`;
        }

        if (options.includes('optimization')) {
            analysis += `⚡ **Optimization Suggestions:**\n`;
            analysis += `• Consider caching frequently used values\n`;
            analysis += `• Optimize loops and conditional statements\n`;
            analysis += `• Review gas usage for contract functions\n\n`;
        }

        if (options.includes('best-practices')) {
            analysis += `✅ **Best Practices Review:**\n`;
            analysis += `• Good variable naming conventions\n`;
            analysis += `• Consider adding more comments\n`;
            analysis += `• Follow consistent code formatting\n\n`;
        }

        if (options.includes('documentation')) {
            analysis += `📚 **Documentation Recommendations:**\n`;
            analysis += `• Add function parameter descriptions\n`;
            analysis += `• Include usage examples\n`;
            analysis += `• Document return values and exceptions\n\n`;
        }

        analysis += `**Next Steps:**\n`;
        analysis += `• Would you like me to provide specific code improvements?\n`;
        analysis += `• I can generate documentation or tests for this code\n`;
        analysis += `• Ask me about any specific concerns!`;

        this.addChatMessage('agent', analysis);
    }

    requestCodeReview() {
        this.addChatMessage('user', 'I would like a comprehensive code review of my project.');
        
        setTimeout(() => {
            const response = `📋 **Comprehensive Code Review**

I'll review your entire CodeDAO project. Please provide:

**For Smart Contracts:**
• Contract files (.sol)
• Test files
• Deployment scripts

**For Dashboard:**
• HTML/CSS/JavaScript files
• Configuration files
• Any backend code

**Review Areas:**
• **Security** - Vulnerability assessment
• **Performance** - Gas optimization, load times
• **Code Quality** - Structure, readability, maintainability
• **Testing** - Coverage and test quality
• **Documentation** - Completeness and clarity

You can share files individually or provide a repository link. What would you like to start with?`;

            this.addChatMessage('agent', response);
        }, 1000);
    }

    handleSuggestionAction(action, suggestion) {
        switch (action) {
            case 'connect-wallet':
                this.addChatMessage('agent', `
🦊 **Wallet Connection Assistance**

I'll help you connect your wallet! Here's what I can do:

1. **Troubleshoot Connection Issues** - Debug wallet problems
2. **Multi-Wallet Support** - Set up MetaMask, Coinbase, WalletConnect
3. **Network Configuration** - Ensure Base network is properly configured
4. **Transaction Optimization** - Optimize gas fees and transaction speed

Try connecting your wallet now, and let me know if you encounter any issues!
                `);
                break;
                
            case 'setup-extension':
                this.addChatMessage('agent', `
🔧 **VS Code Extension Setup**

Let me guide you through setting up the CodeDAO extension:

1. **Installation** - Download and install the extension
2. **Configuration** - Connect to your wallet and configure settings
3. **Testing** - Verify the extension is tracking your coding
4. **Optimization** - Maximize your CODE token earnings

The extension tracks your coding in real-time and rewards you with CODE tokens. Would you like step-by-step setup instructions?
                `);
                break;
                
            case 'analyze-dashboard':
                this.addChatMessage('agent', `
📊 **Dashboard Analysis Starting...**

I'm analyzing your CodeDAO dashboard for:

• **Performance Metrics** - Load times, bundle size, optimization opportunities
• **User Experience** - Navigation, accessibility, mobile responsiveness  
• **Web3 Integration** - Wallet connections, transaction handling
• **Security** - Frontend security best practices
• **Feature Completeness** - Missing functionality, enhancement opportunities

Analysis will be complete in a moment. I'll provide specific recommendations for improvements!
                `);
                
                // Simulate analysis
                setTimeout(() => {
                    this.addChatMessage('agent', `
✅ **Dashboard Analysis Complete**

**Findings:**
• **Performance: 8/10** - Good load times, minor optimization opportunities
• **UX: 9/10** - Excellent design, very user-friendly
• **Web3: 7/10** - Solid integration, could add more wallet options
• **Security: 8/10** - Good practices, recommend adding CSP headers

**Recommendations:**
1. **Add loading states** for better user feedback
2. **Implement error boundaries** for better error handling  
3. **Add transaction history** feature
4. **Optimize images** with lazy loading

Would you like detailed implementation guidance for any of these improvements?
                    `);
                }, 3000);
                break;
        }
    }

    loadUserPreferences() {
        // Load user preferences from localStorage
        const preferences = localStorage.getItem('codedao_agent_preferences');
        if (preferences) {
            this.userPreferences = JSON.parse(preferences);
        } else {
            this.userPreferences = {
                autoConnect: false,
                notifications: true,
                analysisDepth: 'standard',
                preferredLanguage: 'en'
            };
        }
    }

    saveUserPreferences() {
        localStorage.setItem('codedao_agent_preferences', JSON.stringify(this.userPreferences));
    }
}

// Initialize AI Agent when dashboard loads
document.addEventListener('DOMContentLoaded', () => {
    window.codeDAOAgent = new CodeDAOAIAgent();
});

// Export for global access
window.CodeDAOAIAgent = CodeDAOAIAgent; 