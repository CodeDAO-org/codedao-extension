# CodeDAO Wallet Dashboard

A fully functional web3 dashboard that connects to wallets and displays CODE token balances.

## 🚀 Features

- **Multi-Wallet Support**: MetaMask, Coinbase Wallet, WalletConnect
- **Real-time Balance**: Live CODE token balance reading
- **Base Network**: Automatic Base network switching
- **Responsive Design**: Mobile-friendly interface
- **Live Notifications**: User feedback for all actions

## 📋 Setup Instructions

### 1. Files Included
- `index.html` - Main dashboard interface
- `styles.css` - Complete styling with glassmorphism design
- `wallet.js` - Wallet connection and token interaction logic

### 2. Configuration
Your Moralis API key is already configured in `wallet.js`:
```javascript
const MORALIS_API_KEY = "eyJhbGciOiJI..."; // Already set
const CODE_TOKEN_ADDRESS = "0x1F8b43F7aeD0D1b524Ec5b4930C19098E8D4fbD0";
```

### 3. Deploy Options

#### Option A: Local Testing
```bash
# Serve files locally
cd dashboard
python -m http.server 8000
# Open http://localhost:8000
```

#### Option B: GitHub Pages
1. Upload files to your GitHub repo under `docs/` folder
2. Enable GitHub Pages in repo settings
3. Point to `docs/` folder

#### Option C: Netlify/Vercel
1. Upload the `dashboard/` folder
2. Deploy as static site

## 🔧 How It Works

### Wallet Connection Flow
1. User clicks wallet button (MetaMask/Coinbase/WalletConnect)
2. App requests account access
3. Automatically switches to Base network
4. Reads CODE token balance using ethers.js
5. Updates UI with live balance

### Token Balance Reading
```javascript
// The app reads your CODE token balance like this:
const contract = new ethers.Contract(CODE_TOKEN_ADDRESS, ERC20_ABI, provider);
const balance = await contract.balanceOf(userAccount);
```

### Network Handling
- Automatically detects current network
- Prompts user to switch to Base if needed
- Adds Base network if not in wallet

## 🎯 Testing Instructions

### 1. **Test MetaMask Connection**
- Click "🦊 MetaMask" button
- Approve connection in MetaMask
- Should show your address and CODE balance

### 2. **Test Network Switching**
- Connect on different network (e.g., Ethereum)
- App should prompt to switch to Base
- Should read balance after switching

### 3. **Test Balance Reading**
- Connected wallet should show real CODE balance
- If you have 0 CODE, it shows "0.00 CODE"
- USD value calculated at $0.10 per CODE (mock price)

### 4. **Test Claim Function**
- Click "Claim Rewards" when connected
- Shows demo notification (not real claiming yet)

## 🔗 Integration with Your Ecosystem

### Current Integration Points
- **Contract**: Reads from `0x1F8b43F7aeD0D1b524Ec5b4930C19098E8D4fbD0`
- **Network**: Base Mainnet (Chain ID: 8453)
- **ABI**: Uses your `CodeDAOToken_ABI.json` schema

### Future Enhancements
- Connect to `SimpleDistributor.sol` for real claiming
- Add transaction history
- Integrate with your VS Code extension
- Real-time price feeds

## 🔍 Troubleshooting

### "MetaMask not detected"
- Ensure MetaMask extension is installed
- Refresh page after installing

### "Wrong network" 
- App will prompt to switch to Base
- Click "Switch Network" in MetaMask

### "Balance shows 0"
- Verify you're on Base network
- Check if you actually have CODE tokens
- Contract address: `0x1F8b43F7aeD0D1b524Ec5b4930C19098E8D4fbD0`

### Connection issues
- Try disconnecting and reconnecting
- Clear browser cache
- Check browser console for errors

## 📱 Mobile Support

The dashboard is fully responsive and works on:
- iOS Safari
- Android Chrome
- Mobile MetaMask browser
- Mobile wallet apps

## 🎨 Customization

### Colors & Branding
Edit `styles.css` to match your brand:
```css
/* Change gradient background */
body {
    background: linear-gradient(135deg, #YOUR_COLOR1, #YOUR_COLOR2);
}

/* Change card colors */
.card {
    background: rgba(255, 255, 255, 0.15);
}
```

### Add More Wallets
Add new wallet support in `wallet.js`:
```javascript
// Add in connectWallet() function
case 'newwallet':
    account = await connectNewWallet();
    break;
```

## 🚀 Production Deployment

1. **Upload these 3 files** to your web server
2. **Test all wallet connections** 
3. **Verify Base network switching works**
4. **Check CODE balance reading is accurate**

## 📊 Current Status

- ✅ Wallet connections working
- ✅ CODE balance reading functional  
- ✅ Base network auto-switching
- ✅ Responsive mobile design
- ⏳ Real claiming integration (next step)

Your dashboard is **ready to deploy and use immediately**! Users can connect wallets and see their real CODE token balances.

---

*Dashboard built with Moralis Web3 SDK and ethers.js* 